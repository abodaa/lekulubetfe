import React, { useState, useEffect } from "react";
import BottomNav from "../components/BottomNav";
import { useAuth } from "../lib/auth/AuthProvider";
import { apiFetch } from "../lib/api/client";
import { useT } from "../contexts/Languagecontext";
import { motion } from "framer-motion";
import {
  FaHistory,
  FaGamepad,
  FaTrophy,
  FaCalendarAlt,
  FaArrowUp,
} from "react-icons/fa";
import { GiConfirmed } from "react-icons/gi";

export default function History({ onNavigate }) {
  const { sessionId, user } = useAuth();
  const t = useT();
  const [games, setGames] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [userStats, setUserStats] = useState({
    totalGamesPlayed: 0,
    totalGamesWon: 0,
    winRate: 0,
  });

  useEffect(() => {
    if (!sessionId) {
      setLoading(false);
      return;
    }

    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort("timeout"), 12000);

    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);

        // Fetch profile stats (same as Scores page)
        const profileData = await apiFetch("/user/profile", {
          sessionId,
          signal: controller.signal,
        }).catch(() => null);

        // Fetch games list
        const gamesData = await apiFetch("/user/games", {
          sessionId,
          signal: controller.signal,
        }).catch(() => ({ games: [] }));

        let gamesList = gamesData?.games || [];

        // ========== FIX: Process games to correctly identify wins ==========
        gamesList = gamesList.map((game) => {
          // Check if current user is in winners array
          const isWinner = game?.winners?.some((winner) => {
            const winnerId =
              winner?.userId?._id || winner?.userId || winner?.id;
            return String(winnerId) === String(user?.id);
          });

          // Also check userResult if exists
          const hasUserResultWon = game?.userResult?.won === true;

          // Determine if user won this game
          const won = isWinner || hasUserResultWon;

          // Get prize amount if won
          let prize = game?.userResult?.prize || 0;
          if (isWinner && !prize) {
            // Calculate prize from winners array
            const winnerInfo = game?.winners?.find((w) => {
              const winnerId = w?.userId?._id || w?.userId || w?.id;
              return String(winnerId) === String(user?.id);
            });
            prize = winnerInfo?.prize || 0;
          }

          console.log(
            `Game ${game?.gameId}: winners=${JSON.stringify(game?.winners)}, isWinner=${isWinner}, won=${won}`,
          );

          return {
            ...game,
            userResult: {
              won: won,
              prize: prize,
              participated: true,
            },
          };
        });
        // ========== END FIX ==========

        setGames(gamesList);

        // Calculate stats from processed games list
        const totalGames = gamesList.length;
        const gamesWon = gamesList.filter(
          (g) => g?.userResult?.won === true,
        ).length;
        const winRate =
          totalGames > 0 ? Math.round((gamesWon / totalGames) * 100) : 0;

        // Use profile stats if available, otherwise use calculated
        if (profileData?.user) {
          setUserStats({
            totalGamesPlayed: profileData.user.totalGamesPlayed || totalGames,
            totalGamesWon: profileData.user.totalGamesWon || gamesWon,
            winRate:
              profileData.user.totalGamesPlayed > 0
                ? Math.round(
                    (profileData.user.totalGamesWon /
                      profileData.user.totalGamesPlayed) *
                      100,
                  )
                : winRate,
          });
        } else {
          setUserStats({
            totalGamesPlayed: totalGames,
            totalGamesWon: gamesWon,
            winRate: winRate,
          });
        }

        console.log("Stats calculated:", { totalGames, gamesWon, winRate });
      } catch (error) {
        console.error("Failed to fetch game history:", error);
        setError(t("history.load_error"));
      } finally {
        clearTimeout(timeoutId);
        setLoading(false);
      }
    };

    fetchData();

    return () => {
      controller.abort();
      clearTimeout(timeoutId);
    };
  }, [sessionId]);

  const formatDate = (dateString) => {
    if (!dateString) return "N/A";
    try {
      return new Date(dateString).toLocaleDateString();
    } catch {
      return "N/A";
    }
  };

  return (
    <div className="min-h-screen bg-[radial-gradient(110%_70%_at_50%_0%,#16243f_0%,transparent_55%),linear-gradient(180deg,#0e1830_0%,#0a0f1c_55%,#06080f_100%)]">
      {/* Header */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-b from-[#0e1830]/90 to-transparent backdrop-blur-md pt-safe px-4 py-3">
        <div className="flex items-center justify-between max-w-md mx-auto">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-white/10 backdrop-blur border border-white/20 flex items-center justify-center">
              <FaHistory className="text-yellow-400" size={14} />
            </div>
            <span className="text-white/70 text-xs font-medium">
              {t("history.header")}
            </span>
          </div>
        </div>
      </div>

      <main className="px-4 pb-24 pt-16">
        {/* Stats Cards */}
        {!loading && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="grid grid-cols-3 gap-3 mb-6"
          >
            <div className="bg-gradient-to-b from-white/[0.06] to-white/[0.02] backdrop-blur-xl rounded-xl border border-white/10 shadow-[0_6px_24px_rgba(0,0,0,0.3)] p-3 text-center">
              <FaGamepad className="text-white/40 mx-auto mb-1" size={14} />
              <div className="text-white font-bold text-lg">
                {userStats.totalGamesPlayed}
              </div>
              <div className="text-white/30 text-[9px] uppercase tracking-wider">
                {t("scores.games")}
              </div>
            </div>
            <div className="bg-gradient-to-b from-white/[0.06] to-white/[0.02] backdrop-blur-xl rounded-xl border border-white/10 shadow-[0_6px_24px_rgba(0,0,0,0.3)] p-3 text-center">
              <FaTrophy className="text-yellow-400 mx-auto mb-1" size={14} />
              <div className="text-yellow-400 font-bold text-lg">
                {userStats.totalGamesWon}
              </div>
              <div className="text-white/30 text-[9px] uppercase tracking-wider">
                {t("scores.wins")}
              </div>
            </div>
            <div className="bg-gradient-to-b from-white/[0.06] to-white/[0.02] backdrop-blur-xl rounded-xl border border-white/10 shadow-[0_6px_24px_rgba(0,0,0,0.3)] p-3 text-center">
              <GiConfirmed className="text-green-400 mx-auto mb-1" size={14} />
              <div className="text-green-400 font-bold text-lg">
                {userStats.winRate}%
              </div>
              <div className="text-white/30 text-[9px] uppercase tracking-wider">
                {t("profile.win_rate")}
              </div>
            </div>
          </motion.div>
        )}

        {/* Error State */}
        {error && !loading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="rounded-xl bg-red-500/10 border border-red-500/30 p-4 text-center mb-4"
          >
            <p className="text-red-400 text-xs mb-2">{error}</p>
            <button
              onClick={() => window.location.reload()}
              className="px-3 py-1 rounded-full bg-red-500/20 text-red-400 text-[10px] font-medium hover:bg-red-500/30 transition-all"
            >
              {t("common.try_again")}
            </button>
          </motion.div>
        )}

        {/* Games List */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <h3 className="text-white/40 text-[10px] font-medium uppercase tracking-wider mb-2 px-1">
            {t("history.recent")}
          </h3>

          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="w-6 h-6 border-2 border-white/20 border-t-white rounded-full animate-spin" />
            </div>
          ) : !games || games.length === 0 ? (
            <div className="rounded-xl bg-white/5 backdrop-blur border border-white/10 p-8 text-center">
              <FaGamepad className="text-white/20 mx-auto mb-2" size={24} />
              <p className="text-white/30 text-xs">{t("history.no_games")}</p>
            </div>
          ) : (
            <div className="space-y-2">
              {games.slice(0, 20).map((game, idx) => {
                const isWin = game?.userResult?.won === true;
                return (
                  <div
                    key={game?.id || idx}
                    className="bg-gradient-to-b from-white/[0.06] to-white/[0.02] backdrop-blur-xl rounded-xl border border-white/10 shadow-[0_6px_24px_rgba(0,0,0,0.3)] p-3"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div
                          className={`w-7 h-7 rounded-full flex items-center justify-center ${
                            isWin ? "bg-green-500/20" : "bg-red-500/20"
                          }`}
                        >
                          {isWin ? (
                            <FaTrophy className="text-yellow-400" size={12} />
                          ) : (
                            <FaArrowUp className="text-red-400" size={12} />
                          )}
                        </div>
                        <div>
                          <p className="text-white text-xs font-medium">
                            {t("history.game_label", {
                              id: game?.gameId || t("common.na"),
                            })}
                          </p>
                          <div className="flex items-center gap-2 mt-0.5">
                            <FaCalendarAlt className="text-white/20" size={8} />
                            <p className="text-white/30 text-[9px]">
                              {formatDate(game?.finishedAt)}
                            </p>
                          </div>
                        </div>
                      </div>
                      <div
                        className={`px-2 py-0.5 rounded-full text-[9px] font-medium ${
                          isWin
                            ? "bg-green-500/20 text-green-400"
                            : "bg-red-500/20 text-red-400"
                        }`}
                      >
                        {isWin ? t("history.won") : t("history.lost")}
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-[10px]">
                      <div className="flex items-center gap-3">
                        <div>
                          <span className="text-white/30">
                            {t("history.stake")}
                          </span>
                          <span className="text-white ml-1">
                            {game?.stake || 0} {t("common.etb")}
                          </span>
                        </div>
                        <div>
                          <span className="text-white/30">
                            {t("history.prize")}
                          </span>
                          <span className="text-green-400 ml-1">
                            {game?.userResult?.prize || 0} {t("common.etb")}
                          </span>
                        </div>
                      </div>
                      <div className="text-white/30 text-[9px]">
                        {game?.status || "N/A"}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </motion.div>
      </main>

      <BottomNav current="history" onNavigate={onNavigate} />
    </div>
  );
}
