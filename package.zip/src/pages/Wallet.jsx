import React, { useEffect, useState } from "react";
import BottomNav from "../components/BottomNav";
import DepositModal from "../components/DepositModal.jsx";
import { useAuth } from "../lib/auth/AuthProvider.jsx";
import { useT } from "../contexts/Languagecontext.jsx";
import { apiFetch } from "../lib/api/client.js";
import { motion } from "framer-motion";
import {
  FaWallet,
  FaCoins,
  FaHistory,
  FaUserCircle,
  FaCheckCircle,
  FaExclamationCircle,
  FaPlus,
} from "react-icons/fa";
import { GiMoneyStack, GiPlayButton } from "react-icons/gi";
import { FiArrowDownLeft, FiArrowUpRight } from "react-icons/fi";

export default function Wallet({
  onNavigate,
  pendingAction,
  onPendingActionHandled,
}) {
  const { sessionId, user, isLoading: authLoading } = useAuth();
  const t = useT();
  const [wallet, setWallet] = useState({
    main: 0,
    play: 0,
    coins: 0,
    playDeposited: 0,
    bonus: 0, // ADDED
    withdrawableMain: 0,
  });
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("balance");
  const [depositModalOpen, setDepositModalOpen] = useState(false);

  // Bot's Deposit button deep-links here via ?page=wallet&action=deposit
  // (see App.jsx). Open the modal as soon as we're mounted with that pending,
  // then tell the parent it's been handled so it doesn't fire again if the
  // user leaves and comes back to this tab through the bottom nav.
  useEffect(() => {
    if (pendingAction === "deposit") {
      setDepositModalOpen(true);
      onPendingActionHandled?.();
    }
  }, [pendingAction, onPendingActionHandled]);
  const [transactions, setTransactions] = useState([]);
  const [profileData, setProfileData] = useState(null);
  const [displayPhone, setDisplayPhone] = useState(null);
  const [displayRegistered, setDisplayRegistered] = useState(false);
  const [historyLoading, setHistoryLoading] = useState(false);

  // Listen for wallet updates from WebSocket
  useEffect(() => {
    const handleWalletUpdate = (event) => {
      if (event.detail && event.detail.type === "wallet_update") {
        const { main, play, coins, source, bonus, withdrawableMain } =
          event.detail.payload;
        setWallet((prev) => ({
          ...prev,
          main: main ?? prev.main,
          play: play ?? prev.play,
          coins: coins ?? prev.coins,
          bonus: bonus ?? prev.bonus,
          withdrawableMain: withdrawableMain ?? prev.withdrawableMain,
        }));
        if (source === "win") {
          console.log("Success: Congratulations! You won the game!");
        }
      }
    };
    window.addEventListener("walletUpdate", handleWalletUpdate);
    return () => window.removeEventListener("walletUpdate", handleWalletUpdate);
  }, []);

  // Fetch wallet and profile data once
  useEffect(() => {
    if (authLoading || !sessionId) {
      setLoading(false);
      return;
    }
    const fetchData = async () => {
      try {
        setLoading(true);
        try {
          const walletData = await apiFetch("/wallet", { sessionId });
          // Safely get values with fallbacks
          const mainValue = walletData.main ?? walletData.balance ?? 0;
          const playValue = walletData.play ?? 0;
          const bonusValue = walletData.bonus ?? 0;
          const coinsValue = walletData.coins ?? 0;
          const playDepositedValue = walletData.playDeposited ?? 0;
          const withdrawableMainValue =
            walletData.withdrawableMain ?? mainValue;

          setWallet({
            main: mainValue,
            play: playValue,
            coins: coinsValue,
            playDeposited: playDepositedValue,
            bonus: bonusValue,
            withdrawableMain: withdrawableMainValue,
          });
        } catch (walletError) {
          console.error("Wallet fetch error:", walletError);
          try {
            const profile = await apiFetch("/user/profile", { sessionId });
            setProfileData(profile);
            setDisplayPhone(profile?.user?.phone || null);
            setDisplayRegistered(!!profile?.user?.isRegistered);
            if (profile?.wallet) {
              const mainValue =
                profile.wallet.main ?? profile.wallet.balance ?? 0;
              const playValue = profile.wallet.play ?? 0;
              const bonusValue = profile.wallet.bonus ?? 0;
              setWallet({
                main: mainValue,
                play: playValue,
                coins: profile.wallet.coins || 0,
                playDeposited: profile.wallet.playDeposited || 0,
                bonus: bonusValue,
                withdrawableMain: profile.wallet.withdrawableMain ?? mainValue,
              });
            }
          } catch (e) {
            console.error("Profile fetch error:", e);
          }
        }
      } catch (error) {
        console.error("Failed to fetch wallet data:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [sessionId, authLoading]);

  // Lightweight refresh used after a successful deposit — re-pulls the wallet
  // (and, if the user's looking at it, their transaction history) rather than
  // trying to hand-patch every field locally, since the deposit response
  // doesn't include the new absolute Bonus wallet total (only how much was
  // added), and history needs the new deposit row anyway.
  const refreshWalletAndHistory = async () => {
    try {
      const walletData = await apiFetch("/wallet", { sessionId });
      setWallet({
        main: walletData.main ?? walletData.balance ?? 0,
        play: walletData.play ?? 0,
        coins: walletData.coins ?? 0,
        playDeposited: walletData.playDeposited ?? 0,
        bonus: walletData.bonus ?? 0,
        withdrawableMain: walletData.withdrawableMain ?? walletData.main ?? 0,
      });
    } catch (e) {
      console.error("Post-deposit wallet refresh failed:", e);
    }
    if (activeTab === "history") {
      try {
        setHistoryLoading(true);
        const transactionData = await apiFetch("/user/transactions", {
          sessionId,
        });
        setTransactions(transactionData.transactions?.transactions || []);
      } catch (e) {
        console.error("Post-deposit history refresh failed:", e);
      } finally {
        setHistoryLoading(false);
      }
    }
  };

  // Fetch transactions only when history tab is active
  useEffect(() => {
    if (!sessionId || activeTab !== "history") return;
    const fetchTransactions = async () => {
      try {
        setHistoryLoading(true);
        const transactionData = await apiFetch("/user/transactions", {
          sessionId,
        });
        setTransactions(transactionData.transactions?.transactions || []);
      } catch (error) {
        console.error("Failed to fetch transactions:", error);
        setTransactions([]);
      } finally {
        setHistoryLoading(false);
      }
    };
    fetchTransactions();
  }, [sessionId, activeTab]);

  // Types that move money OUT of the user's wallet. Withdrawals are stored
  // with a positive amount, so sign alone can't determine direction.
  const OUTGOING_TYPES = [
    "withdrawal",
    "game_bet",
    "transfer_out",
    "coin_spend",
  ];
  const isOutgoingTx = (type, amount) =>
    OUTGOING_TYPES.includes(type) || Number(amount) < 0;

  const getTransactionIcon = (type, amount) => {
    if (type === "deposit") return <FiArrowDownLeft size={14} />;
    if (type === "game_win") return <FiArrowDownLeft size={14} />;
    return isOutgoingTx(type, amount) ? (
      <FiArrowUpRight size={14} />
    ) : (
      <FiArrowDownLeft size={14} />
    );
  };

  // Format phone number for display (mask middle digits)
  const formatPhoneNumber = (phone) => {
    if (!phone) return null;
    const phoneStr = String(phone);
    if (phoneStr.length >= 10) {
      return phoneStr.slice(0, 4) + "****" + phoneStr.slice(-4);
    }
    return phoneStr;
  };

  return (
    <div className="min-h-screen bg-[radial-gradient(110%_70%_at_50%_0%,#16243f_0%,transparent_55%),linear-gradient(180deg,#0e1830_0%,#0a0f1c_55%,#06080f_100%)]">
      {/* Header */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-b from-[#0e1830]/90 to-transparent backdrop-blur-md px-4 py-3">
        <div className="flex items-center justify-between max-w-md mx-auto">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-white/10 backdrop-blur border border-white/20 flex items-center justify-center">
              <FaWallet className="text-yellow-400" size={14} />
            </div>
            <span className="text-white/70 text-xs font-medium">
              {t("wallet.header")}
            </span>
          </div>
        </div>
      </div>

      <main className="px-4 pb-24 pt-16">
        {/* User Info Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-4"
        >
          <div className="rounded-xl bg-white/5 backdrop-blur border border-white/10 p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-gradient-to-r from-amber-500 to-amber-600 flex items-center justify-center">
                  <FaUserCircle className="text-white" size={16} />
                </div>
                <div>
                  <p className="text-white text-sm font-medium">
                    {profileData?.user?.firstName ||
                      user?.firstName ||
                      "Player"}
                  </p>
                  {displayPhone && (
                    <p className="text-white/40 text-[10px]">
                      {formatPhoneNumber(displayPhone)}
                    </p>
                  )}
                </div>
              </div>
              {displayRegistered ? (
                <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-green-500/20">
                  <FaCheckCircle className="text-green-400" size={10} />
                  <span className="text-green-400 text-xs">
                    {t("wallet.verified")}
                  </span>
                </div>
              ) : (
                <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-green-500/20">
                  <FaCheckCircle className="text-green-400" size={10} />
                  <span className="text-green-400 text-xs">
                    {t("wallet.verified")}
                  </span>
                </div>
              )}
            </div>
          </div>
        </motion.div>

        {/* Tab Switcher */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.05 }}
          className="mb-4"
        >
          <div className="flex gap-1 bg-white/5 rounded-full p-0.5">
            <button
              onClick={() => setActiveTab("balance")}
              className={`flex-1 flex items-center justify-center gap-1 py-1.5 rounded-full text-xs font-medium transition-all ${
                activeTab === "balance"
                  ? "bg-white/20 text-white"
                  : "text-white/40 hover:text-white/60"
              }`}
            >
              <FaWallet size={12} />
              {t("wallet.tab_balance")}
            </button>
            <button
              onClick={() => setActiveTab("history")}
              className={`flex-1 flex items-center justify-center gap-1 py-1.5 rounded-full text-xs font-medium transition-all ${
                activeTab === "history"
                  ? "bg-white/20 text-white"
                  : "text-white/40 hover:text-white/60"
              }`}
            >
              <FaHistory size={12} />
              {t("wallet.tab_history")}
            </button>
          </div>
        </motion.div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="w-6 h-6 border-2 border-white/20 border-t-white rounded-full animate-spin" />
          </div>
        ) : activeTab === "balance" ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="space-y-3"
          >
            {/* Main Wallet Card */}
            <div className="rounded-xl bg-white/5 backdrop-blur border border-white/10 p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-blue-500/20 flex items-center justify-center">
                    <GiMoneyStack className="text-blue-400" size={16} />
                  </div>
                  <span className="text-white/60 text-xs uppercase tracking-wider">
                    {t("wallet.main")}
                  </span>
                </div>
                <span className="text-white/50 text-xs">
                  {t("wallet.withdrawable")}
                </span>
              </div>
              <div className="flex items-end justify-between gap-2">
                <div>
                  <div className="text-white text-2xl font-bold">
                    {wallet.main?.toLocaleString() || 0}{" "}
                    <span className="text-white/40 text-sm">
                      {t("common.etb")}
                    </span>
                  </div>
                  {/* Only surface the withdrawable-vs-total split when it
                      actually matters — i.e. some of the balance is still
                      locked deposit principal — so users with an
                      all-winnings balance don't see a redundant second
                      number. */}
                  {wallet.withdrawableMain < wallet.main && (
                    <div className="mt-1 text-amber-400/80 text-[11px]">
                      {t("wallet.withdrawable_amount", {
                        amount: wallet.withdrawableMain?.toLocaleString() || 0,
                      })}
                    </div>
                  )}
                </div>
                <button
                  onClick={() => setDepositModalOpen(true)}
                  className="shrink-0 flex items-center gap-1.5 px-3 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 text-white text-xs font-semibold hover:scale-[1.03] transition-transform"
                >
                  <FaPlus size={9} />
                  {t("wallet.deposit_btn")}
                </button>
              </div>
            </div>

            {/* Bonus Wallet Card */}
            <div className="rounded-xl bg-white/5 backdrop-blur border border-white/10 p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center">
                    <FaCoins className="text-amber-400" size={16} />
                  </div>
                  <span className="text-white/60 text-xs uppercase tracking-wider">
                    {t("wallet.bonus")}
                  </span>
                </div>
                <span className="text-white/50 text-xs">
                  {t("wallet.promotional")}
                </span>
              </div>
              <div className="text-white text-2xl font-bold">
                {wallet.bonus?.toLocaleString() || 0}{" "}
                <span className="text-white/40 text-sm">{t("common.etb")}</span>
              </div>
              <div className="text-white/30 text-xs mt-1">
                {t("wallet.bonus_hint")}
              </div>
            </div>

            {/* Coins Card */}
            <div className="rounded-xl bg-white/5 backdrop-blur border border-white/10 p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-yellow-500/20 flex items-center justify-center">
                    <FaCoins className="text-yellow-400" size={16} />
                  </div>
                  <span className="text-white/60 text-xs uppercase tracking-wider">
                    {t("wallet.coins")}
                  </span>
                </div>
                <span className="text-white/50 text-xs">
                  {t("wallet.earn_from_bets")}
                </span>
              </div>
              <div className="text-yellow-400 text-2xl font-bold">
                {wallet.coins?.toLocaleString() || 0}
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <div className="rounded-xl bg-white/5 backdrop-blur border border-white/10 overflow-hidden">
              <div className="px-3 py-2 border-b border-white/5">
                <h3 className="text-white/40 text-[10px] font-medium uppercase tracking-wider">
                  {t("wallet.recent_tx")}
                </h3>
              </div>

              {historyLoading ? (
                <div className="flex items-center justify-center py-12">
                  <div className="w-6 h-6 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                </div>
              ) : transactions.length === 0 ? (
                <div className="text-center py-12">
                  <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-white/5 flex items-center justify-center">
                    <FaHistory className="text-white/20" size={24} />
                  </div>
                  <p className="text-white/50 text-xs">{t("wallet.no_tx")}</p>
                </div>
              ) : (
                <div className="divide-y divide-white/5">
                  {transactions.slice(0, 20).map((transaction, idx) => {
                    // Direction is derived from the transaction TYPE, not the
                    // sign of the stored amount (withdrawals store a positive
                    // amount but are money leaving the wallet).
                    const outgoing = isOutgoingTx(
                      transaction.type,
                      transaction.amount,
                    );
                    const isPositive = !outgoing;
                    const magnitude = Math.abs(Number(transaction.amount) || 0);
                    const statusLabel =
                      transaction.status === "completed"
                        ? t("tx.success")
                        : transaction.status === "cancelled"
                          ? t("tx.cancelled")
                          : transaction.status === "failed"
                            ? t("tx.failed")
                            : transaction.status === "processing"
                              ? t("tx.processing")
                              : transaction.status === "pending"
                                ? t("tx.pending")
                                : transaction.status || t("tx.pending");
                    const statusColor =
                      transaction.status === "cancelled" ||
                      transaction.status === "failed"
                        ? "text-red-400/70"
                        : transaction.status === "pending" ||
                            transaction.status === "processing"
                          ? "text-amber-400/70"
                          : "text-white/40";
                    return (
                      <div key={transaction.id || idx} className="p-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div
                              className={`w-7 h-7 rounded-full flex items-center justify-center shrink-0 ${
                                isPositive
                                  ? "bg-green-500/30 text-green-400"
                                  : "bg-red-500/30 text-red-400"
                              }`}
                            >
                              {getTransactionIcon(
                                transaction.type,
                                transaction.amount,
                              )}
                            </div>
                            <div>
                              <p className="text-white text-xs font-medium">
                                {transaction.description ||
                                  (transaction.type === "deposit"
                                    ? t("tx.deposit")
                                    : transaction.type === "game_win"
                                      ? t("tx.game_win")
                                      : transaction.type === "game_bet"
                                        ? t("tx.game_bet")
                                        : transaction.type === "withdrawal"
                                          ? t("tx.withdrawal")
                                          : t("tx.transaction"))}
                              </p>
                              {transaction.counterparty &&
                                transaction.counterparty.name && (
                                  <p className="text-white/50 text-[9px]">
                                    {transaction.counterparty.direction === "to"
                                      ? "→ "
                                      : "← "}
                                    {transaction.counterparty.name}
                                    {transaction.counterparty.phone
                                      ? ` · ${transaction.counterparty.phone}`
                                      : ""}
                                  </p>
                                )}
                              <p className="text-white/40 text-[9px]">
                                {new Date(
                                  transaction.createdAt,
                                ).toLocaleString()}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p
                              className={`text-xs font-bold ${
                                isPositive ? "text-green-400" : "text-red-400"
                              }`}
                            >
                              {isPositive ? `+${magnitude}` : `-${magnitude}`}{" "}
                              {t("common.etb")}
                            </p>
                            <p
                              className={`text-[9px] uppercase ${statusColor}`}
                            >
                              {statusLabel}
                            </p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </main>

      <BottomNav current="wallet" onNavigate={onNavigate} />

      <DepositModal
        isOpen={depositModalOpen}
        onClose={() => setDepositModalOpen(false)}
        sessionId={sessionId}
        onSuccess={refreshWalletAndHistory}
      />
    </div>
  );
}
