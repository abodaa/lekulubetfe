import React, { useState, useEffect } from "react";
import BottomNav from "../components/BottomNav";
import { useAuth } from "../lib/auth/AuthProvider";
import { useLanguage } from "../contexts/Languagecontext";
import { apiFetch } from "../lib/api/client";
import { motion } from "framer-motion";
import {
  FaUserCircle,
  FaWallet,
  FaGamepad,
  FaCoins,
  FaTrophy,
  FaUsers,
  FaGift,
  FaLink,
  FaVolumeUp,
  FaVolumeMute,
  FaCheckCircle,
  FaPercentage,
  FaMoneyBillWave,
} from "react-icons/fa";
import { GiMoneyStack, GiPlayButton } from "react-icons/gi";

export default function Profile({ onNavigate }) {
  const [profileData, setProfileData] = useState({
    user: {
      firstName: "User",
      lastName: "",
      phone: null,
      isRegistered: false,
      totalGamesPlayed: 0,
      totalGamesWon: 0,
      registrationDate: new Date(),
    },
    wallet: { balance: 0, main: 0, play: 0, coins: 0, gamesWon: 0, bonus: 0 }, // ADDED bonus
  });
  const [inviteStats, setInviteStats] = useState({
    totalInvites: 0,
    totalRewards: 0,
    totalDepositsFromInvited: 0,
    estimatedDepositRewards: 0,
    rewardRate: "Loading...",
    rewardWallet: "Loading...",
    inviteCode: null,
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { user, sessionId, isLoading: authLoading } = useAuth();
  const { t, lang, setLang } = useLanguage();

  const displayName =
    profileData.user?.firstName || user?.firstName || "Player";
  const initials = displayName.charAt(0).toUpperCase();

  const fetchProfileData = React.useCallback(async () => {
    if (authLoading || !sessionId) {
      setLoading(false);
      return;
    }
    try {
      setLoading(true);
      setError(null);

      // Fetch profile, wallet, and invite stats
      const profilePromise = apiFetch("/user/profile", { sessionId }).catch(
        (err) => {
          console.warn("Profile fetch error:", err);
          return null;
        },
      );

      const walletPromise = apiFetch("/wallet", { sessionId }).catch((err) => {
        console.warn("Wallet fetch error:", err);
        return {
          balance: 0,
          main: 0,
          coins: 0,
          gamesWon: 0,
          bonus: 0,
        };
      });

      const invitePromise = apiFetch("/user/invite-stats", { sessionId }).catch(
        (err) => {
          console.warn("Invite stats fetch error:", err);
          return null;
        },
      );

      const [profileRes, walletRes, inviteRes] = await Promise.all([
        profilePromise,
        walletPromise,
        invitePromise,
      ]);

      console.log("Invite stats response:", inviteRes);
      console.log("Wallet response:", walletRes);

      const userInfo = profileRes?.user || {
        firstName: user?.firstName || "User",
        lastName: user?.lastName || "",
        phone: user?.phone || null,
        isRegistered: user?.isRegistered || false,
        totalGamesPlayed: user?.totalGamesPlayed || 0,
        totalGamesWon: user?.totalGamesWon || 0,
        registrationDate: new Date(),
      };

      // Safely get wallet values with fallbacks
      const mainValue = walletRes.main ?? walletRes.balance ?? 0;
      const coinsValue = walletRes.coins ?? 0;
      const gamesWonValue = profileRes?.user.totalGamesWon ?? 0;
      const bonusValue = walletRes.bonus ?? 0;

      setProfileData({
        user: userInfo,
        wallet: {
          balance: walletRes.balance ?? 0,
          main: mainValue,
          coins: coinsValue,
          gamesWon: gamesWonValue,
          bonus: bonusValue,
        },
      });

      if (inviteRes) {
        console.log("📊 Invite stats received:", inviteRes);
        console.log(
          "💰 totalDepositsFromInvited:",
          inviteRes.totalDepositsFromInvited,
        );
        setInviteStats({
          totalInvites: inviteRes.totalInvites || 0,
          totalRewards: inviteRes.totalRewards || 0,
          totalDepositsFromInvited: inviteRes.totalDepositsFromInvited || 0,
          estimatedDepositRewards: inviteRes.estimatedDepositRewards || 0,
          rewardRate:
            inviteRes.rewardRate || `1 ${t("common.etb")} per registration`,
          rewardWallet: inviteRes.rewardWallet || "Main Wallet (Withdrawable)",
          inviteCode: inviteRes.inviteCode || null,
        });
      } else {
        // Fallback: try to generate invite code by calling generate endpoint
        try {
          const generateRes = await apiFetch("/user/generate-invite-code", {
            sessionId,
            method: "POST",
          }).catch(() => null);
          if (generateRes && generateRes.inviteCode) {
            setInviteStats((prev) => ({
              ...prev,
              inviteCode: generateRes.inviteCode,
            }));
          }
        } catch (genError) {
          console.warn("Failed to generate invite code:", genError);
        }
      }
    } catch (error) {
      console.error("Failed to fetch profile data:", error);
      setError(t("profile.load_error"));
    } finally {
      setLoading(false);
    }
  }, [sessionId, authLoading, user]);

  useEffect(() => {
    fetchProfileData();
  }, [fetchProfileData]);

  const StatCard = ({ icon, label, value, sublabel, color = "white" }) => (
    <div className="bg-gradient-to-b from-white/[0.06] to-white/[0.02] backdrop-blur-xl rounded-xl border border-white/10 shadow-[0_6px_24px_rgba(0,0,0,0.3)] p-3 text-center">
      <div className="flex items-center justify-center mb-2">
        <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
          {icon}
        </div>
      </div>
      <div
        className={`text-white font-bold text-lg ${color === "green" ? "text-green-400" : color === "yellow" ? "text-yellow-400" : color === "purple" ? "text-amber-400" : "text-white"}`}
      >
        {value}
      </div>
      <div className="text-white/50 text-[10px] uppercase tracking-wider">
        {label}
      </div>
      {sublabel && (
        <div className="text-white/30 text-[9px] mt-1">{sublabel}</div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-[radial-gradient(110%_70%_at_50%_0%,#16243f_0%,transparent_55%),linear-gradient(180deg,#0e1830_0%,#0a0f1c_55%,#06080f_100%)]">
      {/* Header */}
      <div className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-b from-[#0e1830]/90 to-transparent backdrop-blur-md px-4 py-3">
        <div className="flex items-center justify-between max-w-md mx-auto">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-white/10 backdrop-blur border border-white/20 flex items-center justify-center">
              <FaUserCircle className="text-yellow-400" size={14} />
            </div>
            <span className="text-white/70 text-xs font-medium">
              {t("profile.header")}
            </span>
          </div>
        </div>
      </div>

      <main className="px-4 pb-24 pt-16">
        {/* Profile Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-6"
        >
          <div className="relative inline-block mb-3">
            <div className="w-20 h-20 rounded-full bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center border-2 border-white/20 shadow-xl">
              <span className="text-white text-3xl font-bold">{initials}</span>
            </div>
            {profileData.user?.isRegistered && (
              <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-green-500 flex items-center justify-center border-2 border-white/20">
                <FaCheckCircle size={12} className="text-white" />
              </div>
            )}
          </div>
          <h1 className="text-white text-xl font-bold">{displayName}</h1>
          {profileData.user?.isRegistered && (
            <span className="inline-block mt-1 px-2 py-0.5 rounded-full bg-green-500/20 text-green-400 text-[10px] font-medium">
              {t("profile.verified")}
            </span>
          )}
        </motion.div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="w-6 h-6 border-2 border-white/20 border-t-white rounded-full animate-spin" />
          </div>
        ) : error ? (
          <div className="text-center py-12">
            <div className="w-12 h-12 mx-auto mb-2 rounded-full bg-red-500/20 flex items-center justify-center">
              <span className="text-2xl">❌</span>
            </div>
            <p className="text-white/50 text-xs mb-3">{error}</p>
            <button
              onClick={fetchProfileData}
              className="px-4 py-1.5 rounded-full bg-white/10 text-white text-xs font-medium hover:bg-white/20 transition-all"
            >
              {t("common.try_again")}
            </button>
          </div>
        ) : (
          <>
            {/* Stats Grid - 3 columns for better layout */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="grid grid-cols-2 gap-3 mb-6"
            >
              <StatCard
                icon={<GiMoneyStack size={16} className="text-blue-400" />}
                label={t("wallet.main")}
                value={`${profileData.wallet.main?.toLocaleString() || 0} ${t("common.etb")}`}
                sublabel={t("wallet.main_sub")}
              />

              <StatCard
                icon={<FaGift size={16} className="text-amber-400" />}
                label={t("wallet.bonus")}
                value={`${profileData.wallet.bonus?.toLocaleString() || 0} ${t("common.etb")}`}
                sublabel={t("wallet.bonus_sub")}
                // color="purple"
              />
              <StatCard
                icon={<FaCoins size={16} className="text-yellow-400" />}
                label={t("wallet.coins")}
                value={profileData.wallet.coins?.toLocaleString() || 0}
                sublabel={t("wallet.coins_sub")}
                // color="yellow"
              />
              <StatCard
                icon={<FaGamepad size={16} className="text-emerald-400" />}
                label={t("profile.games_played")}
                value={profileData.user.totalGamesPlayed.toLocaleString() || 0}
                sublabel={t("profile.games_played_sub")}
                // color="green"
              />
              <StatCard
                icon={<FaTrophy size={16} className="text-yellow-400" />}
                label={t("profile.games_won")}
                value={profileData.user.totalGamesWon.toLocaleString() || 0}
                sublabel={t("profile.games_won_sub")}
                // color="yellow"
              />
            </motion.div>

            {/* Language Switcher */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.12 }}
              className="rounded-xl bg-white/5 backdrop-blur border border-white/10 p-4 mb-4"
            >
              <div className="flex items-center gap-2 mb-3">
                <div className="w-6 h-6 rounded-full bg-amber-500/20 flex items-center justify-center">
                  <span className="text-xs">🌐</span>
                </div>
                <h3 className="text-white/70 text-xs font-medium uppercase tracking-wider">
                  {t("lang.title")}
                </h3>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { code: "en", label: t("lang.english") },
                  { code: "am", label: t("lang.amharic") },
                ].map((opt) => (
                  <button
                    key={opt.code}
                    onClick={() => setLang(opt.code)}
                    className={`py-2 rounded-lg text-sm font-medium border transition-all ${
                      lang === opt.code
                        ? "bg-amber-500/20 border-amber-400/40 text-amber-300"
                        : "bg-white/5 border-white/10 text-white/60 hover:bg-white/10"
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </motion.div>

            {/* Invite Stats Section */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.15 }}
              className="rounded-xl bg-white/5 backdrop-blur border border-white/10 p-4 mb-4"
            >
              <div className="flex items-center gap-2 mb-3">
                <div className="w-6 h-6 rounded-full bg-amber-500/20 flex items-center justify-center">
                  <FaUsers size={12} className="text-amber-400" />
                </div>
                <h3 className="text-white/70 text-xs font-medium uppercase tracking-wider">
                  {t("profile.referral")}
                </h3>
              </div>

              {/* Stats Row */}
              <div className="flex justify-between items-center mb-3">
                <div className="text-center flex-1">
                  <p className="text-white/40 text-[9px] uppercase">
                    {t("profile.invites")}
                  </p>
                  <p className="text-white text-lg font-bold">
                    {inviteStats.totalInvites || 0}
                  </p>
                </div>
                <div className="text-center flex-1 border-x border-white/10">
                  <p className="text-white/40 text-[9px] uppercase">
                    {t("profile.reg_rewards")}
                  </p>
                  <p className="text-green-400 text-lg font-bold">
                    {inviteStats.totalRewards?.toLocaleString() || 0}{" "}
                    {t("common.etb")}
                  </p>
                </div>
              </div>

              {/* Reward Rate Info */}
              <div className="bg-white/5 rounded-lg p-2 mb-3">
                <div className="flex items-center justify-between">
                  {/* <div className="flex items-center gap-2">
                    <FaPercentage size={10} className="text-yellow-400" />
                    <span className="text-white/50 text-[9px]">
                      Reward Rate
                    </span>
                  </div> */}
                  <span className="text-yellow-400 text-xs font-medium">
                    {inviteStats.rewardRate ||
                      `1 ${t("common.etb")} per registration`}
                  </span>
                </div>
                <div className="flex items-center justify-between mt-1">
                  <div className="flex items-center gap-2">
                    <FaMoneyBillWave size={10} className="text-emerald-400" />
                    <span className="text-white/50 text-xs">
                      {t("profile.credited_to")}
                    </span>
                  </div>
                  <span className="text-emerald-400 text-xs font-medium">
                    {inviteStats.rewardWallet || "Main Wallet (Withdrawable)"}
                  </span>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </main>

      <BottomNav current="profile" onNavigate={onNavigate} />
    </div>
  );
}
